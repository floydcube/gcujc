from setuptools import setup, find_packages

setup(name='servo',
      version='1.0.1',
      description='',
      author=' ',
      author_email='tul54967@temple.edu',
      license='MIT',
      url='https://cflwww.eng.temple.edu',
      packages=find_packages(),
      install_requires=[],
#      entry_points={
#       'console_scripts':[
#          'imu=testimu:callimu'
#       ]
#     }
)
